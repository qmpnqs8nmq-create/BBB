# OpenClaw Diagnostics Export

Attach this zip to the bug report. It is designed for maintainers to inspect without asking for raw logs first.

## Generated

Generated: 2026-09-15T02:43:27.544Z
OpenClaw: 2026.9.4

## Contents

- no stability bundle included (missing)
- sanitized log tail (634 line(s), inspected 678754 byte(s), raw messages omitted)
- config shape included (parsed)
- gateway status snapshot included (status/gateway-status.json)
- gateway health snapshot included (health/gateway-health.json)

## Maintainer Quick Read

- `manifest.json`: file inventory and privacy notes
- `diagnostics.json`: top-level summary of config, logs, Bonjour/mDNS, stability, status, and health
- `config/sanitized.json`: config values with credentials, private identifiers, and prompt text redacted
- `status/gateway-status.json`: sanitized service/connectivity snapshot
- `health/gateway-health.json`: sanitized Gateway health snapshot
- `logs/openclaw-sanitized.jsonl`: sanitized log summaries and metadata
- `stability/latest.json`: newest payload-free stability bundle, when available

## Privacy

- raw chat text, webhook bodies, tool outputs, tokens, cookies, and secrets are not included intentionally
- log records keep operational summaries and safe metadata fields
- status and health snapshots redact secret fields, payload-like fields, and account/message identifiers
- config output keeps useful settings but redacts secrets, private identifiers, and prompt text
